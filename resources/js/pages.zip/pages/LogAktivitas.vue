<template>
  <div class="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
    <SidebarAdmin />
    <div class="flex-1 flex flex-col">
      <Navbar />
      <main class="flex-1 p-6">
        <div class="mb-8">
          <h1 class="text-3xl font-bold text-slate-900 dark:text-white">Log Aktivitas</h1>
          <p class="text-slate-700 dark:text-slate-300">Riwayat aktivitas admin (audit trail).</p>
        </div>

        <div class="app-card app-card--cyan p-6">
          <div class="rounded-2xl bg-slate-100 dark:bg-slate-800/50 p-4 text-sm text-slate-700 dark:text-slate-300">
            Belum ada data log aktivitas.
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script>
import SidebarAdmin from '../components/layout/SidebarAdmin.vue'
import Navbar from '../components/layout/Navbar.vue'

export default {
  name: 'LogAktivitas',
  components: {
    SidebarAdmin,
    Navbar,
  },
}
</script>

<style scoped>
/* Additional styles if needed */
</style>

