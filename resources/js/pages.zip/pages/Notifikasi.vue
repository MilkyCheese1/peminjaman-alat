<template>
  <div class="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
    <component :is="sidebarComponent" />
    <div class="flex-1 flex flex-col">
      <Navbar />
      <main class="flex-1 p-6">
        <div class="mb-8">
          <h1 class="text-3xl font-bold text-slate-900 dark:text-white">Notifikasi</h1>
          <p class="text-slate-700 dark:text-slate-300">Daftar notifikasi untuk {{ roleLabel }}</p>
        </div>

        <div class="app-card app-card--cyan p-6">
          <div class="rounded-2xl bg-slate-100 dark:bg-slate-800/50 p-4 text-sm text-slate-700 dark:text-slate-300">
            Belum ada notifikasi.
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script>
import SidebarAdmin from '../components/layout/SidebarAdmin.vue'
import SidebarOwner from '../components/layout/SidebarOwner.vue'
import SidebarStaff from '../components/layout/SidebarStaff.vue'
import SidebarPeminjam from '../components/layout/SidebarPeminjam.vue'
import Navbar from '../components/layout/Navbar.vue'

const sidebarByRole = {
  admin: SidebarAdmin,
  owner: SidebarOwner,
  staff: SidebarStaff,
  peminjam: SidebarPeminjam,
}

const roleLabelByRole = {
  admin: 'Admin',
  owner: 'Owner',
  staff: 'Staff',
  peminjam: 'Peminjam',
}

export default {
  name: 'Notifikasi',
  components: {
    SidebarAdmin,
    SidebarOwner,
    SidebarStaff,
    SidebarPeminjam,
    Navbar,
  },
  props: {
    role: {
      type: String,
      required: true,
    },
  },
  computed: {
    sidebarComponent() {
      return sidebarByRole[this.role] ?? SidebarPeminjam
    },
    roleLabel() {
      return roleLabelByRole[this.role] ?? 'Pengguna'
    },
  },
}
</script>

<style scoped>
/* Additional styles if needed */
</style>

